import React,{Component} from "react";
import './UserView.css';

export default class UserView extends Component{



 render(){

     return(
  

       

<body>
  <center>
  <h1 style={{color:'white'}}><i><b>The Best Place To Choose Your Destination</b></i></h1>
  </center>
<div class="wrapper">
  <h1 style={{color:'white'}}>Ella</h1>
  <div class="image i1"></div>
  <div class="details"><h1><em>Luxury Hotel</em></h1>
  <h2>98 Acress Resort</h2>
  <p>LKR 12,000</p></div>
  <a href ="insert" type="submit" class="btn btn-primary" style={{ marginTop: '20px', color:'white', width:'245px', height:'38px', margin:'10px'}} ><b>BOOK NOW</b></a>
  
</div>

<div class="wrapper">
  <h1 style={{color:'white'}}>Galle</h1>
  <div class="image i2"></div>
  <div class="details"><h1>Luxury Hotel<em></em></h1>
  <h2>Amari Galle</h2>
  <p>LKR 24,000</p></div>
  <a href ="insert" type="submit" class="btn btn-primary" style={{ marginTop: '20px', color:'white', width:'245px', height:'38px', margin:'10px'}} ><b>BOOK NOW</b></a>
</div>

<div class="wrapper">
  <h1 style={{color:'white'}}>Hikkaduwa</h1>
  <div class="image i3"></div>
  <div class="details"><h1><em>Luxury Hotel</em></h1>
  <h2>Citrus Hikkaduwa</h2>
  <p>LKR 10,000</p></div>
  <a href ="insert" type="submit" class="btn btn-primary" style={{ marginTop: '20px', color:'white', width:'245px', height:'38px', margin:'10px'}} ><b>BOOK NOW</b></a>
</div>

<div class="wrapper">
  <h1 style={{color:'white'}}>Dabulla</h1>
  <div class="image i4"></div>
  <div class="details"><h1><em>Luxury Hotel</em></h1>
  <h2>Heritance Kandalama</h2>
  <p>LKR 15,000</p></div>
  <a href ="insert" type="submit" class="btn btn-primary" style={{ marginTop: '20px', color:'white', width:'245px', height:'38px', margin:'10px'}} ><b>BOOK NOW</b></a>
</div>

<div class="wrapper">
  <h1 style={{color:'white'}}>Kandy</h1>
  <div class="image i5"></div>
  <div class="details"><h1><em>Luxury Hotel</em></h1>
  <h2>Mountain Blue</h2>
  <p>LKR 24,000</p></div>
  <a href ="insert" type="submit" class="btn btn-primary" style={{ marginTop: '20px', color:'white', width:'245px', height:'38px', margin:'10px'}} ><b>BOOK NOW</b></a>
</div>

<div class="wrapper">
  <h1 style={{color:'white'}}>Kandy</h1>
  <div class="image i6"></div>
  <div class="details"><h1><em>Luxury Hotel</em></h1>
  <h2>Sidney Rest</h2>
  <p>LKR 11,000</p></div>
  <a href ="insert" type="submit" class="btn btn-primary" style={{ marginTop: '20px', color:'white', width:'245px', height:'38px', margin:'10px'}} ><b>BOOK NOW</b></a>
</div>

<a href ="all2" type="submit" class="btn btn-primary" style={{ marginTop: '20px', color:'white', width:'245px', height:'38px', margin:'10px'}} ><b>SEARCH HOTEL</b></a>

</body>
            

        





     )





 }




}
    

